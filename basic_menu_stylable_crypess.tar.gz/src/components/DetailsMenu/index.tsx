export { default } from './DetailsMenu';
export type { DetailsMenuProps } from './DetailsMenu';
