export { default } from './DetailsMenuItem';
export type { DetailsMenuItemProps } from './DetailsMenuItem';
